// Interfaz para lista simple
public interface InterfazListaS {

    void insertarInicio(fut equipo);

    void insertarFinal(fut equipo);

    void eliminarInicio();

    void eliminarFinal();

    fut buscar(String nombre);

    boolean estaVacia();

    int contar();

    void mostrarLista();
}