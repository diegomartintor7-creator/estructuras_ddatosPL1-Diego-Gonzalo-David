// nodo de la lista simple que guarda un dato y apunta al siguiente
public class Nodo {

    fut dato;       // el dato que queremos almacenar en el nodo
    Nodo siguiente;

    // crea un nodo con el dato dado, sin enlazar todavía
    public Nodo(fut dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}