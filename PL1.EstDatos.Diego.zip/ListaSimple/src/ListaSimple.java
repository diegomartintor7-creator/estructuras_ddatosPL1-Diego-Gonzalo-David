// lista simplemente enlazada que guarda equipos de fútbol
public class ListaSimple implements InterfazListaS {

    private Nodo cabeza; // primer nodo de la lista

    // inicializa la lista vacía
    public ListaSimple() {
        cabeza = null;
    }

    @Override
    public boolean estaVacia() {
        return cabeza == null; // true si no hay nodos
    }

    @Override
    public void insertarInicio(fut equipo) {
        Nodo nuevo = new Nodo(equipo);
        nuevo.siguiente = cabeza; // el nuevo apunta al antiguo primero
        cabeza = nuevo;           // ahora el nuevo es la cabeza
    }

    @Override
    public void insertarFinal(fut equipo) {
        Nodo nuevo = new Nodo(equipo);

        if (estaVacia()) {
            cabeza = nuevo; // si la lista estaba vacía, se convierte en cabeza
        } else {
            Nodo actual = cabeza;
            while (actual.siguiente != null) { // avanzamos hasta el último
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo; // enlazamos el nuevo al final
        }
    }

    @Override
    public void eliminarInicio() {
        if (!estaVacia()) {
            cabeza = cabeza.siguiente; // quitamos el primer nodo
        }
    }

    @Override
    public void eliminarFinal() {
        if (estaVacia()) return;

        if (cabeza.siguiente == null) { // solo hay un nodo
            cabeza = null;
            return;
        }

        Nodo actual = cabeza;
        while (actual.siguiente.siguiente != null) { // llegamos al penúltimo
            actual = actual.siguiente;
        }
        actual.siguiente = null; // quitamos el último nodo
    }

    @Override
    public fut buscar(String nombre) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.dato.getNombre().equalsIgnoreCase(nombre)) {
                return actual.dato; // encontramos el equipo
            }
            actual = actual.siguiente;
        }
        return null; // no estaba en la lista
    }

    @Override
    public int contar() {
        int contador = 0;
        Nodo actual = cabeza;
        while (actual != null) {
            contador++;        // vamos contando los nodos
            actual = actual.siguiente;
        }
        return contador;
    }

    @Override
    public void mostrarLista() {
        Nodo actual = cabeza;
        while (actual != null) {
            System.out.println(actual.dato); // mostramos el equipo
            actual = actual.siguiente;
        }
    }
}