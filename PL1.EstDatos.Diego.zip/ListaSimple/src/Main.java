// clase para probar cómo funciona la lista simple con equipos de fútbol
public class Main {

    public static void main(String[] args) {

        ListaSimple lista = new ListaSimple(); // creamos la lista vacía

        // creamos algunos equipos de fútbol
        fut e1 = new fut("Real Madrid", "Madrid", 15);
        fut e2 = new fut("Barcelona", "Barcelona", 5);
        fut e3 = new fut("Bayern Munich", "Munich", 6);
        fut e4 = new fut("Manchester City", "Manchester", 1);

        // insertar equipos en la lista, mezclando inicio y final
        lista.insertarInicio(e1);
        lista.insertarFinal(e2);
        lista.insertarFinal(e3);
        lista.insertarInicio(e4);

        System.out.println("LISTA SIMPLE:");
        lista.mostrarLista(); // mostramos todos los equipos

        System.out.println("\nTotal equipos: " + lista.contar()); // número de equipos

        System.out.println("\nBuscando Bayern Munich...");
        System.out.println(lista.buscar("Bayern Munich")); // buscamos un equipo por nombre

        System.out.println("\nEliminando inicio y final...");
        lista.eliminarInicio(); // quitamos el primer equipo
        lista.eliminarFinal();  // quitamos el último equipo

        System.out.println("\nLISTA ACTUALIZADA:");
        lista.mostrarLista(); // mostramos la lista después de eliminar
    }
}