// representa un equipo de fútbol con nombre, ciudad y títulos ganados
public class fut {

    private String nombre;
    private String ciudad;
    private int titulos;

    // constructor para inicializar todos los datos del equipo
    public fut(String nombre, String ciudad, int titulos) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.titulos = titulos;
    }

    // devuelve el nombre del equipo
    public String getNombre() {
        return nombre;
    }

    // devuelve la ciudad del equipo
    public String getCiudad() {
        return ciudad;
    }

    // devuelve el número de títulos ganados
    public int getTitulos() {
        return titulos;
    }

    // representación del equipo
    @Override
    public String toString() {
        return "Equipo: " + nombre + " | Ciudad: " + ciudad + " | Titulos: " + titulos;
    }
}