// lista circular de equipos, donde el último nodo apunta al primero
public class ListaCirc implements InterfazListaCirc {

    private Nodo ultimo; // último nodo de la lista, su siguiente es la cabeza

    public ListaCirc() {
        ultimo = null; // lista vacía al inicio
    }

    @Override
    public boolean estaVacia() {
        return ultimo == null; // true si no hay nodos
    }

    @Override
    public void insertar(fut equipo) {
        Nodo nuevo = new Nodo(equipo);

        if (estaVacia()) {
            // primer nodo, apunta a sí mismo
            ultimo = nuevo;
            ultimo.siguiente = ultimo;
        } else {
            // insertamos después del último y actualizamos 'ultimo'
            nuevo.siguiente = ultimo.siguiente;
            ultimo.siguiente = nuevo;
            ultimo = nuevo;
        }
    }

    @Override
    public void eliminar() {
        if (estaVacia()) return;

        Nodo primero = ultimo.siguiente;

        if (primero == ultimo) {
            // solo hay un nodo, lista queda vacía
            ultimo = null;
        } else {
            // eliminamos el primer nodo, el último apunta al nuevo primero
            ultimo.siguiente = primero.siguiente;
        }
    }

    @Override
    public fut buscar(String nombre) {
        if (estaVacia()) return null;

        Nodo actual = ultimo.siguiente;

        do {
            if (actual.dato.getNombre().equalsIgnoreCase(nombre)) {
                return actual.dato; // encontramos el equipo
            }
            actual = actual.siguiente;
        } while (actual != ultimo.siguiente);

        return null; // no se encontró
    }

    @Override
    public int contar() {
        if (estaVacia()) return 0;

        int contador = 0;
        Nodo actual = ultimo.siguiente;

        do {
            contador++;
            actual = actual.siguiente;
        } while (actual != ultimo.siguiente);

        return contador;
    }

    @Override
    public void mostrarLista() {
        if (estaVacia()) {
            System.out.println("La lista está vacía");
            return;
        }

        Nodo actual = ultimo.siguiente;

        do {
            System.out.println(actual.dato);
            actual = actual.siguiente;
        } while (actual != ultimo.siguiente);
    }
}