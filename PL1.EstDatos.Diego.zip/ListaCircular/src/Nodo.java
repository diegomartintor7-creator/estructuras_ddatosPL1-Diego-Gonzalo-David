// nodo de lista circular que guarda un equipo y apunta al siguiente
public class Nodo {

    fut dato;
    Nodo siguiente;

    // inicializa el nodo con el equipo dado
    public Nodo(fut dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}