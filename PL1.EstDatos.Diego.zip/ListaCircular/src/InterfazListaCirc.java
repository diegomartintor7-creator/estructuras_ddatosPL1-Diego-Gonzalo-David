// Interfaz para la lista circular
public interface InterfazListaCirc {

    void insertar(fut equipo);

    void eliminar();

    fut buscar(String nombre);

    boolean estaVacia();

    int contar();

    void mostrarLista();
}