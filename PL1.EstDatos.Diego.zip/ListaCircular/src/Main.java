// prueba de la lista circular de equipos
public class Main {

    public static void main(String[] args) {

        ListaCirc lista = new ListaCirc(); // lista vacía

        // crear equipos
        fut e1 = new fut("Real Madrid", "Madrid", 15);
        fut e2 = new fut("Barcelona", "Barcelona", 5);
        fut e3 = new fut("Bayern Munich", "Munich", 6);
        fut e4 = new fut("Manchester City", "Manchester", 1);

        // insertar todos los equipos en la lista circular
        lista.insertar(e1);
        lista.insertar(e2);
        lista.insertar(e3);
        lista.insertar(e4);

        System.out.println("LISTA CIRCULAR:");
        lista.mostrarLista(); // recorrer e imprimir la lista completa

        System.out.println("\nTotal equipos: " + lista.contar()); // número de equipos

        System.out.println("\nBuscando Barcelona...");
        System.out.println(lista.buscar("Barcelona")); // buscar un equipo por nombre

        System.out.println("\nEliminando primer equipo...");
        lista.eliminar(); // eliminar el primer nodo de la lista

        System.out.println("\nLISTA ACTUALIZADA:");
        lista.mostrarLista(); // mostrar cómo quedó la lista después de eliminar
    }
}