// representa un equipo de fútbol con nombre, ciudad y títulos
public class fut {

    private String nombre;
    private String ciudad;
    private int titulos;

    // inicializa un equipo con sus datos
    public fut(String nombre, String ciudad, int titulos) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.titulos = titulos;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public int getTitulos() {
        return titulos;
    }

    // formato legible para mostrar el equipo
    @Override
    public String toString() {
        return "Equipo: " + nombre + " | Ciudad: " + ciudad + " | Titulos: " + titulos;
    }
}