// nodo para la pila, guarda un equipo y referencias al siguiente y anterior
public class Nodo {

    fut dato;
    Nodo siguiente;
    Nodo anterior;

    // inicializa un nodo con el equipo dado
    public Nodo(fut dato) {
        this.dato = dato;
        this.siguiente = null;
        this.anterior = null;
    }
}