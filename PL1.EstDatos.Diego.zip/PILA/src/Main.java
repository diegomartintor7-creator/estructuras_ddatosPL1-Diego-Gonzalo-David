// prueba de la pila de equipos usando nodos doblemente enlazados
public class Main {

    public static void main(String[] args) {

        ListaDobleP pila = new ListaDobleP(); // pila vacía

        // crear equipos
        fut e1 = new fut("Real Madrid", "Madrid", 15);
        fut e2 = new fut("Barcelona", "Barcelona", 5);
        fut e3 = new fut("Bayern Munich", "Munich", 6);
        fut e4 = new fut("Manchester City", "Manchester", 1);

        // apilar equipos (último en entrar, primero en salir)
        pila.push(e1);
        pila.push(e2);
        pila.push(e3);
        pila.push(e4);

        System.out.println("PILA DE EQUIPOS:");
        pila.mostrarPila(); // mostrar desde la cima hacia abajo

        System.out.println("\nEquipo en la cima:");
        System.out.println(pila.peek()); // ver el elemento de la cima

        System.out.println("\nSacando equipo de la pila...");
        System.out.println(pila.pop()); // quitar la cima

        System.out.println("\nPILA ACTUALIZADA:");
        pila.mostrarPila(); // mostrar cómo quedó la pila

        System.out.println("\nTotal equipos en la pila: " + pila.contar()); // contar elementos restantes
    }
}