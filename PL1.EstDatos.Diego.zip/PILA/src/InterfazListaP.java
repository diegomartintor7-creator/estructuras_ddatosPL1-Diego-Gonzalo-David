// Interfaz de la pila
public interface InterfazListaP {

    void push(fut equipo);

    fut pop();

    fut peek();

    boolean estaVacia();

    int contar();

    void mostrarPila();
}