// Implementación de una pila usando nodos doblemente enlazados
public class ListaDobleP implements InterfazListaP {

    private Nodo cima;

    // Constructor
    public ListaDobleP() {
        cima = null;
    }

    // Comprueba si la pila está vacía
    @Override
    public boolean estaVacia() {
        return cima == null;
    }

    // Insertar elemento en la cima de la pila
    @Override
    public void push(fut equipo) {

        Nodo nuevo = new Nodo(equipo);

        if (estaVacia()) {
            cima = nuevo;
        } else {
            nuevo.siguiente = cima;
            cima.anterior = nuevo;
            cima = nuevo;
        }
    }

    // Eliminar elemento de la cima
    @Override
    public fut pop() {

        if (estaVacia()) {
            return null;
        }

        fut eliminado = cima.dato;

        cima = cima.siguiente;

        if (cima != null) {
            cima.anterior = null;
        }

        return eliminado;
    }

    // Ver el elemento en la cima
    @Override
    public fut peek() {

        if (estaVacia()) {
            return null;
        }

        return cima.dato;
    }

    // Contar elementos de la pila
    @Override
    public int contar() {

        int contador = 0;
        Nodo actual = cima;

        while (actual != null) {
            contador++;
            actual = actual.siguiente;
        }

        return contador;
    }

    // Mostrar la pila completa
    @Override
    public void mostrarPila() {

        Nodo actual = cima;

        while (actual != null) {
            System.out.println(actual.dato);
            actual = actual.siguiente;
        }
    }
}