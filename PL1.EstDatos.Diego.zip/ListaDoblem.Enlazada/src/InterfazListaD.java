// Interfaz con las operaciones de la lista
public interface InterfazListaD {

    void insertarInicio(fut equipo);

    void insertarFinal(fut equipo);

    void insertarPosicion(fut equipo, int posicion);

    void eliminarInicio();

    void eliminarFinal();

    void eliminarEquipo(String nombre);

    fut buscar(String nombre);

    int contar();

    boolean estaVacia();

    void mostrarAdelante();

    void mostrarAtras();
}