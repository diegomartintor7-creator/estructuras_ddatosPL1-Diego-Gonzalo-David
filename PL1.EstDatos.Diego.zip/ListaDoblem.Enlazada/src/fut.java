// representa un equipo de fútbol con su nombre, ciudad y número de títulos
public class fut {

    private String nombre;
    private String ciudad;
    private int titulos;

    // inicializa un equipo con todos sus datos
    public fut(String nombre, String ciudad, int titulos) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.titulos = titulos;
    }

    // devuelve el nombre del equipo
    public String getNombre() {
        return nombre;
    }

    // devuelve la ciudad del equipo
    public String getCiudad() {
        return ciudad;
    }

    // devuelve la cantidad de títulos ganados
    public int getTitulos() {
        return titulos;
    }

    // para mostrar el equipo
    @Override
    public String toString() {
        return "Equipo: " + nombre + " | Ciudad: " + ciudad + " | Titulos: " + titulos;
    }
}