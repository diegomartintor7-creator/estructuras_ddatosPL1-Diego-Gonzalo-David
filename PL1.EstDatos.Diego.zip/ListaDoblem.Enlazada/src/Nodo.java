// nodo para lista doblemente enlazada, guarda un equipo y apunta a los nodos anterior y siguiente
public class Nodo {

    fut dato;        // el equipo que queremos guardar
    Nodo siguiente;
    Nodo anterior;

    // crea un nodo aislado con el equipo dado
    public Nodo(fut dato) {
        this.dato = dato;
        this.siguiente = null;
        this.anterior = null;
    }
}