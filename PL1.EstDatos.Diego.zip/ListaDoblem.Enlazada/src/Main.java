// clase para probar la lista doblemente enlazada de equipos
public class Main {

    public static void main(String[] args) {

        ListaDoble lista = new ListaDoble(); // lista vacía

        // crear equipos
        fut e1 = new fut("Real Madrid", "Madrid", 15);
        fut e2 = new fut("Barcelona", "Barcelona", 5);
        fut e3 = new fut("Bayern Munich", "Munich", 6);
        fut e4 = new fut("Manchester City", "Manchester", 1);
        fut e5 = new fut("Juventus", "Turin", 2);

        // insertar equipos en distintas posiciones
        lista.insertarInicio(e1);
        lista.insertarFinal(e2);
        lista.insertarFinal(e3);
        lista.insertarPosicion(e4, 1);
        lista.insertarFinal(e5);

        System.out.println("LISTA HACIA ADELANTE");
        lista.mostrarAdelante();

        System.out.println("\nLISTA HACIA ATRAS");
        lista.mostrarAtras();

        System.out.println("\nTotal equipos: " + lista.contar());

        System.out.println("\nBuscando Barcelona...");
        System.out.println(lista.buscar("Barcelona"));

        System.out.println("\nEliminando Bayern Munich...");
        lista.eliminarEquipo("Bayern Munich");

        System.out.println("\nLISTA ACTUALIZADA");
        lista.mostrarAdelante();
    }
}}