// lista doblemente enlazada de equipos, se puede recorrer hacia adelante y atrás
public class ListaDoble implements InterfazListaD {

    private Nodo cabeza; // inicio de la lista
    private Nodo cola;   // final de la lista

    // inicializa la lista vacía
    public ListaDoble() {
        cabeza = null;
        cola = null;
    }

    @Override
    public boolean estaVacia() {
        return cabeza == null; // true si no hay nodos
    }

    @Override
    public void insertarInicio(fut equipo) {
        Nodo nuevo = new Nodo(equipo);
        if (estaVacia()) {
            // si la lista está vacía, el nuevo nodo es cabeza y cola
            cabeza = cola = nuevo;
        } else {
            // enlazamos el nuevo nodo antes de la cabeza
            nuevo.siguiente = cabeza;
            cabeza.anterior = nuevo;
            cabeza = nuevo; // actualizamos la cabeza
        }
    }

    @Override
    public void insertarFinal(fut equipo) {
        Nodo nuevo = new Nodo(equipo);
        if (estaVacia()) {
            cabeza = cola = nuevo; // lista vacía, el nodo es cabeza y cola
        } else {
            // agregamos al final, actualizamos referencias de cola
            cola.siguiente = nuevo;
            nuevo.anterior = cola;
            cola = nuevo;
        }
    }

    @Override
    public void insertarPosicion(fut equipo, int posicion) {
        if (posicion <= 0) {
            insertarInicio(equipo);
            return;
        }

        Nodo nuevo = new Nodo(equipo);
        Nodo actual = cabeza;
        int contador = 0;

        // avanzamos hasta la posición deseada
        while (actual != null && contador < posicion) {
            actual = actual.siguiente;
            contador++;
        }

        if (actual == null) {
            // si llegamos al final, insertamos al final
            insertarFinal(equipo);
        } else {
            // insertamos entre anterior y actual
            Nodo anterior = actual.anterior;
            nuevo.siguiente = actual;
            nuevo.anterior = anterior;

            if (anterior != null) {
                anterior.siguiente = nuevo;
            }
            actual.anterior = nuevo;
        }
    }

    @Override
    public void eliminarInicio() {
        if (estaVacia()) return;

        if (cabeza == cola) {
            // solo hay un nodo, lista queda vacía
            cabeza = cola = null;
        } else {
            cabeza = cabeza.siguiente;
            cabeza.anterior = null; // cortamos el enlace hacia atrás
        }
    }

    @Override
    public void eliminarFinal() {
        if (estaVacia()) return;

        if (cabeza == cola) {
            cabeza = cola = null;
        } else {
            cola = cola.anterior;
            cola.siguiente = null; // cortamos el enlace hacia adelante
        }
    }

    @Override
    public void eliminarEquipo(String nombre) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.dato.getNombre().equalsIgnoreCase(nombre)) {
                if (actual == cabeza) {
                    eliminarInicio();
                    return;
                }
                if (actual == cola) {
                    eliminarFinal();
                    return;
                }
                // quitamos el nodo del medio, enlazando anterior y siguiente
                actual.anterior.siguiente = actual.siguiente;
                actual.siguiente.anterior = actual.anterior;
                return;
            }
            actual = actual.siguiente;
        }
    }

    @Override
    public fut buscar(String nombre) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.dato.getNombre().equalsIgnoreCase(nombre)) {
                return actual.dato; // encontramos el equipo
            }
            actual = actual.siguiente;
        }
        return null; // no está en la lista
    }

    @Override
    public int contar() {
        int contador = 0;
        Nodo actual = cabeza;
        while (actual != null) {
            contador++;
            actual = actual.siguiente;
        }
        return contador;
    }

    @Override
    public void mostrarAdelante() {
        Nodo actual = cabeza;
        while (actual != null) {
            System.out.println(actual.dato); // recorremos del inicio al final
            actual = actual.siguiente;
        }
    }

    @Override
    public void mostrarAtras() {
        Nodo actual = cola;
        while (actual != null) {
            System.out.println(actual.dato); // recorremos del final al inicio
            actual = actual.anterior;
        }
    }
}