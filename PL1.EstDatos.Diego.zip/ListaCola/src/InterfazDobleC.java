// Interfaz de la cola
public interface InterfazDobleC {

    void encolar(fut equipo);

    fut desencolar();

    fut verPrimero();

    boolean estaVacia();

    int contar();

    void mostrarCola();
}
