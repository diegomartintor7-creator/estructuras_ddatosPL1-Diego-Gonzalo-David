// prueba de la cola de equipos usando nodos doblemente enlazados
public class Main {

    public static void main(String[] args) {

        ListaDobleC cola = new ListaDobleC(); // cola vacía

        // crear equipos
        fut e1 = new fut("Real Madrid", "Madrid", 14);
        fut e2 = new fut("Barcelona", "Barcelona", 5);
        fut e3 = new fut("Bayern Munich", "Munich", 6);
        fut e4 = new fut("Manchester City", "Manchester", 1);

        // agregar equipos al final de la cola
        cola.encolar(e1);
        cola.encolar(e2);
        cola.encolar(e3);
        cola.encolar(e4);

        System.out.println("COLA DE EQUIPOS:");
        cola.mostrarCola(); // mostrar todos los elementos

        System.out.println("\nPrimer equipo en la cola:");
        System.out.println(cola.verPrimero()); // ver sin eliminar el frente

        System.out.println("\nDesencolando equipo...");
        System.out.println(cola.desencolar()); // eliminar el frente

        System.out.println("\nCOLA ACTUALIZADA:");
        cola.mostrarCola(); // mostrar cómo quedó la cola

        System.out.println("\nTotal equipos en cola: " + cola.contar()); // contar elementos restantes
    }
}