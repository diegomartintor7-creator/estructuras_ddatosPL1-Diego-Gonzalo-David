// cola de equipos usando nodos doblemente enlazados
public class ListaDobleC implements InterfazDobleC {

    private Nodo frente;     // primer elemento de la cola
    private Nodo finalCola;  // último elemento de la cola

    public ListaDobleC() {
        frente = null;
        finalCola = null; // cola vacía al inicio
    }

    public boolean estaVacia() {
        return frente == null; // true si no hay elementos
    }

    public void encolar(fut equipo) {
        Nodo nuevo = new Nodo(equipo);

        if (estaVacia()) {
            // primer elemento, frente y final son el mismo nodo
            frente = finalCola = nuevo;
        } else {
            // agregamos al final y actualizamos referencias
            finalCola.siguiente = nuevo;
            nuevo.anterior = finalCola;
            finalCola = nuevo;
        }
    }

    public fut desencolar() {
        if (estaVacia()) return null;

        fut equipo = frente.dato;

        if (frente == finalCola) {
            // solo había un elemento, cola queda vacía
            frente = finalCola = null;
        } else {
            // removemos el frente y actualizamos referencias
            frente = frente.siguiente;
            frente.anterior = null;
        }

        return equipo;
    }

    public fut verPrimero() {
        if (estaVacia()) return null;
        return frente.dato; // devuelve el frente sin eliminarlo
    }

    public int contar() {
        int contador = 0;
        Nodo actual = frente;
        while (actual != null) {
            contador++;
            actual = actual.siguiente;
        }
        return contador;
    }

    public void mostrarCola() {
        Nodo actual = frente;
        while (actual != null) {
            System.out.println(actual.dato);
            actual = actual.siguiente;
        }
    }
}