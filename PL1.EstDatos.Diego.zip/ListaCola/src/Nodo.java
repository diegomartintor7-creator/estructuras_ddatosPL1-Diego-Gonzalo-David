// nodo para la estructura tipo cola, guarda un equipo y referencias a siguiente y anterior
public class Nodo {

    fut dato;
    Nodo siguiente;
    Nodo anterior;

    // inicializa un nodo aislado con el equipo dado
    public Nodo(fut dato) {
        this.dato = dato;
        this.siguiente = null;
        this.anterior = null;
    }
}