package org.example;

public interface Interfaz {
    public void add_element(Moto moto);
    public void imprimir();
    public int size();
}
