package org.example;

public class Cola implements Interfaz{
    private Nodo head;

    public int size(){
        Nodo objeto = head;
        int n = 0;
        while(objeto != null){
            objeto = objeto.next;
            n = n + 1;
        }
        return n;
    }


    public void add_element(Moto moto){
        int tamanno = size();
        if(tamanno > 3) add_element2(moto);
        else add_element1(moto);
    }


    public void  add_element1(Moto moto) {
        Nodo Nuevo = new Nodo(moto);
        if (head == null){
            head = Nuevo;
            return;
        }
        Nodo segundo = head;
        Nuevo.next = segundo;
        Nuevo.prev = null;
        head = Nuevo;
        segundo.prev = Nuevo;
    }

    public void  add_element2(Moto moto) {
        Nodo Nuevo = new Nodo(moto);
        Nodo segundo = head;
        Nuevo.next = segundo;
        head = Nuevo;

        Nodo ultimo = head;
        while(ultimo.next != null){
            ultimo = ultimo.next;
        }
        ultimo.prev.next = null;
    }


    public void imprimir(){
        Nodo actual = head;
        while(actual != null){
            System.out.print(actual.moto + " -> ");
            actual = actual.next;
        }
        System.out.println("null");
    }

    public boolean Lista_llena(){
        int tamano = size();
        if(tamano < 3){
            return false;
        }
        else return true;
    }

    }
