package org.example;

public class Main {
    public static void main(String[] args) {
        Cola cola = new Cola();
        cola.add_element(new Moto("Keeway", 15, 125));
        System.out.println("La cola esta llena <- " + cola.Lista_llena());
        cola.add_element(new Moto("Zontes", 40, 350));
        cola.add_element(new Moto("Suzuki", 70, 650));
        cola.add_element(new Moto("Zontes", 93, 703));
        cola.imprimir();
        cola.add_element(new Moto("Kawasaki", 100, 950));
        cola.imprimir();
        System.out.println("La cola esta llena <- " + cola.Lista_llena());
    }
}