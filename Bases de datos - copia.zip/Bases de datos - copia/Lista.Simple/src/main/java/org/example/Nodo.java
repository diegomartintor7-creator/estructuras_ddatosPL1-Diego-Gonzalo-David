package org.example;

public class Nodo {
    Moto moto;
    Nodo next;

    public Nodo(Moto moto){
        this.moto = moto;
        this.next = null;
    }
}
