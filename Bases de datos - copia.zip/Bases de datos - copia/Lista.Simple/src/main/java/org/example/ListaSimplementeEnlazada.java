package org.example;

public class ListaSimplementeEnlazada implements Interfaz {
    private Nodo head;
    public void add_at_end(Moto moto){
        Nodo nuevo = new Nodo(moto);

        if (head == null){
            head = nuevo;
            return;
        }

        Nodo actual = head;
        while (actual.next != null){
            actual = actual.next;
        }
        actual.next = nuevo;
    }

    public void delete_element(Moto moto){
        if (head == null){
            return; // lista vacía
        }

        // Verificar si el primer nodo es el que queremos eliminar
        if (head.moto.equals(moto)){
            head = head.next;
            return; // salir después de eliminar
        }

        Nodo actual = head;
        Nodo anterior = null;

        // Recorrer la lista buscando el nodo que coincida con la moto
        while (actual != null && !actual.moto.equals(moto)){
            anterior = actual;
            actual = actual.next;
        }

        // Si encontramos el nodo, lo eliminamos
        if (actual != null){
            anterior.next = actual.next;
        }
    }


    public void imprimir() {
        Nodo actual = head;
        while (actual != null) {
            System.out.print(actual.moto + " -> ");
            actual = actual.next;
        }
        System.out.println("null");
    }


    public void mas_caballos(int caballos) {

    }
}
