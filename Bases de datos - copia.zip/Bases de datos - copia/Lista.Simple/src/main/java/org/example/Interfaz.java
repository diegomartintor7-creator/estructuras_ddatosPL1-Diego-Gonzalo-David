package org.example;

public interface Interfaz {
    public void add_at_end(Moto moto);
    public void delete_element(Moto moto);
    public void mas_caballos(int caballos);
}
