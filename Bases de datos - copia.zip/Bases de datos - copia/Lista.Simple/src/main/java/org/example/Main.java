package org.example;

public class Main{
    public static void main(String[] args){
        ListaSimplementeEnlazada lista = new ListaSimplementeEnlazada();
        lista.add_at_end(new Moto("Keeway", 15, 125));
        lista.add_at_end(new Moto("Zontes", 40, 350));
        lista.add_at_end(new Moto("Suzuki", 70, 650));
        lista.add_at_end(new Moto("Zontes", 93, 703));
        lista.add_at_end(new Moto("Kawasaki", 85, 800));
        lista.imprimir();
        System.out.println("----------Eliminando Suzuki-----------");
        lista.delete_element(new  Moto("Suzuki", 70, 650));
        lista.imprimir();
    }

}