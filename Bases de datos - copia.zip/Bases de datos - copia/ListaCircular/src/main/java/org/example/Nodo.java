package org.example;

public class Nodo {
    Moto moto;
    Nodo next;
    Nodo prev;

    public Nodo(Moto moto){
        this.moto = moto;
        this.next = null;
        this.prev = null;
    }
}
