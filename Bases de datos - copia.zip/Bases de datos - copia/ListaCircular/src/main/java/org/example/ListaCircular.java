package org.example;

public class ListaCircular implements Interfaz{
    private Nodo head;

    public void add_element(Moto moto){
        Nodo nuevo = new Nodo(moto);
        if(head == null){
            head = new Nodo(moto);
            return;
        }
        if(head.next == null){
            head.next = nuevo;
            head.prev = nuevo;
            nuevo.prev = head;
            nuevo.next = head;
            return;
        }

        nuevo.next = head.next;
        head.next.prev = nuevo;
        head.next = nuevo;
        nuevo.prev = head;
    }
    public void imprimir(){
        System.out.print(head.moto + " -> ");
        Nodo actual = head.next;
        while(!actual.moto.equals(head.moto)){
            System.out.print(actual.moto + " -> ");
            actual = actual.next;
        }
        System.out.println("null");
    }
}
