package org.example;
public class Main{
    public static void main(String[] args){
        ListaCircular lista = new ListaCircular();
        lista.add_element(new Moto("Keeway", 15, 125));
        lista.add_element(new Moto("Zontes", 40, 350));
        lista.add_element(new Moto("Suzuki", 70, 650));
        lista.add_element(new Moto("Zontes", 93, 703));
        lista.add_element(new Moto("Kawasaki", 85, 800));
        lista.imprimir();
    }
}