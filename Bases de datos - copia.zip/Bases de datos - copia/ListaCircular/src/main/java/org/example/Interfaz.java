package org.example;

public interface Interfaz {
}
