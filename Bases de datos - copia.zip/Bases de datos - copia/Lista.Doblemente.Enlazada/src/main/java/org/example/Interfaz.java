package org.example;

public interface Interfaz {
    public void add_at_end(Moto moto);
    public void delete_element(Moto moto);
    public void imprimir();
    public void imprimir_reves();
}
