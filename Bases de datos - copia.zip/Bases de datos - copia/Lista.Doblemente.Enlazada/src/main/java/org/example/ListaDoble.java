package org.example;

public class ListaDoble implements Interfaz {
    private Nodo head;
    public void add_at_end(Moto moto){
        Nodo nuevo = new Nodo(moto);

        if(head == null){
            head = nuevo;
            return;
        }
        Nodo actual = head;
        while(actual.next != null){
            actual = actual.next;
        }
        actual.next = nuevo;
        nuevo.prev = actual;
    }

    public void delete_element(Moto moto) {
        Nodo eliminar = obtener_nodo(moto);
        eliminar.prev.next = eliminar.next;
        eliminar.next.prev = eliminar.prev;
    }

    private Nodo obtener_nodo(Moto moto){
        Nodo temp = head;
        while(temp != null){
            if(temp.moto.equals(moto)){
                return temp;
            }
            temp = temp.next;
        }
        return null;
    }

    public void imprimir() {
        Nodo actual = head;
        while (actual != null) {
            System.out.print(actual.moto + " -> ");
            actual = actual.next;
        }
        System.out.println("null");
    }

    public void imprimir_reves() {
        Nodo primero = head;
        while(primero.next != null){
            primero = primero.next;
        }
        while(primero != null){
            System.out.print(primero.moto + " -> ");
            primero = primero.prev;
        }
        System.out.println("null");
    }
}
