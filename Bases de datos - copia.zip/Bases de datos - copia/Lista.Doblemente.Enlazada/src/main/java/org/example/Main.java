package org.example;

public class Main {
    public static void main(String[] args){
        ListaDoble lista = new ListaDoble();
        lista.add_at_end(new Moto("Keeway", 15, 125));
        lista.add_at_end(new Moto("Zontes", 40, 350));
        lista.add_at_end(new Moto("Suzuki", 70, 650));
        lista.add_at_end(new Moto("Zontes", 93, 703));
        lista.add_at_end(new Moto("Kawasaki", 85, 800));
        lista.imprimir();
        lista.imprimir_reves();
        System.out.println("Borrando Suzuki");
        lista.delete_element(new Moto("Suzuki", 70, 650));
        lista.imprimir();
        lista.imprimir_reves();


    }
}