package org.example;

public class Pila {
    private Nodo head;

    public int size(){
        int n = 1;
        Nodo actual = head;
        while(actual != null){
            actual = actual.next;
            n = n + 1;
        }
        return n;
    }

    public void push(Moto moto){
        Nodo actual = new Nodo(moto);
        int tamano = this.size();
        if(tamano > 3){
            System.out.println("La lista esta llena, no se puede añadir");
            return;
        }
        if(head == null){
            head = actual;
            return;
        }
        actual.next = head;
        head.prev = actual;
        head = actual;
    }

    public Moto pop(){
        if(head == null) return null;
        Nodo actual = head;
        actual.next.prev = null;
        head = actual.next;
        return actual.moto;
    }

    public void imprimir(){
        Nodo actual = head;
        while(actual != null){
            System.out.print(actual.moto + " -> ");
            actual = actual.next;
        }
        System.out.println(" null");
    }
}
