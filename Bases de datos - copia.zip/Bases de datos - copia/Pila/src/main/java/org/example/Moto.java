package org.example;

public class Moto {
    private String marca;
    private int caballos;
    private int cilindrada;

    public Moto(String marca, int caballos, int cilindrada){
        this.marca = marca;
        this.caballos = caballos;
        this.cilindrada = cilindrada;
    }

    public String toString(){
        return marca + "[" + caballos + " cv, " + cilindrada + " cc]";
    }

    public boolean equals(Moto moto){
        if(this == moto) return true;
        else return false;
    }
}
