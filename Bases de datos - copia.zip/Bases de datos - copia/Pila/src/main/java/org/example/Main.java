package org.example;

public class Main{
    public  static void main(String[] args){
        Pila lista = new Pila();

        lista.push(new Moto("Keeway", 15, 125));
        lista.push(new Moto("Zontes", 40, 350));
        lista.push(new Moto("Suzuki", 70, 650));
        lista.push(new Moto("Zontes", 93, 703));
        lista.push(new Moto("Kawasaki", 85, 800));
        lista.imprimir();
        System.out.println("----------Eliminando Suzuki-----------");
        System.out.println(lista.pop());
        lista.imprimir();
        lista.push(new Moto("Zontes", 93, 703));
        lista.imprimir();
    }
}