package org.example;

public class Nodo {
    Moto moto;
    Nodo prev;
    Nodo next;

    public Nodo(Moto moto){
        this.moto = moto;
        this.prev = null;
        this.next = null;
    }
}
